from .rnn_cell_impl_v2 import DropoutWrapper
# from rnn_cell_impl import DropoutWrapper
from .dropout import dropout
# from dropout import dropout
