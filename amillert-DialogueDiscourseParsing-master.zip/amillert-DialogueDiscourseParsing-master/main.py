from Model_v2 import Model
from utils_v2 import load_data, build_vocab, preview_data, get_batches

import os
import random
import time

import tensorflow as tf
import numpy as np


# TODO: fix cuda
# if not os.environ.has_key('CUDA_VISIBLE_DEVICES'):
#     os.environ['CUDA_VISIBLE_DEVICES'] = '0'

FLAGS = tf.compat.v1.flags.FLAGS

# tf.compat.v1.flags.DEFINE_string('word_vector', 'glove.6B.100d.txt', 'word vector')

tf.compat.v1.flags.DEFINE_boolean('train', False, 'train model')
tf.compat.v1.flags.DEFINE_integer('display_interval', 500, 'step interval to display information')
tf.compat.v1.flags.DEFINE_boolean('show_predictions', False, 'show predictions in the test stage')
tf.compat.v1.flags.DEFINE_string('word_vector', 'glove.6B.100d.txt', 'word vector')
tf.compat.v1.flags.DEFINE_string('prefix', 'dev', 'prefix for storing model and log')
tf.compat.v1.flags.DEFINE_integer('vocab_size', 1000, 'vocabulary size')
tf.compat.v1.flags.DEFINE_integer('max_edu_dist', 20, 'maximum distance between two related edus')
tf.compat.v1.flags.DEFINE_integer('dim_embed_word', 100, 'dimension of word embedding')
tf.compat.v1.flags.DEFINE_integer('dim_embed_relation', 100, 'dimension of relation embedding')
tf.compat.v1.flags.DEFINE_integer('dim_feature_bi', 4, 'dimension of binary features')
tf.compat.v1.flags.DEFINE_boolean('use_structured', True, 'use structured encoder')
tf.compat.v1.flags.DEFINE_boolean('use_speaker_attn', True, 'use speaker highlighting mechanism')
tf.compat.v1.flags.DEFINE_boolean('use_shared_encoders', False, 'use shared encoders')
tf.compat.v1.flags.DEFINE_boolean('use_random_structured', False, 'use random structured repr.')
tf.compat.v1.flags.DEFINE_integer('num_epochs', 50, 'number of epochs')
tf.compat.v1.flags.DEFINE_integer('num_units', 256, 'number of hidden units')
tf.compat.v1.flags.DEFINE_integer('num_layers', 1, 'number of RNN layers in encoders')
tf.compat.v1.flags.DEFINE_integer('num_relations', 16, 'number of relation types')
tf.compat.v1.flags.DEFINE_integer('batch_size', 4, 'batch size')
tf.compat.v1.flags.DEFINE_float('keep_prob', 0.5, 'probability to keep units in dropout')
tf.compat.v1.flags.DEFINE_float('learning_rate', 0.1, 'learning rate')
tf.compat.v1.flags.DEFINE_float('learning_rate_decay', 0.98, 'learning rate decay factor')


def get_summary_sum(s, length):
    loss_bi, loss_multi = s[0] / length, s[1] / length
    prec_bi, recall_bi = s[4] * 1. / s[3], s[4] * 1. / s[2]
    f1_bi = 2 * prec_bi * recall_bi / (prec_bi + recall_bi)
    prec_multi, recall_multi = s[5] * 1. / s[3], s[5] * 1. / s[2]
    f1_multi = 2 * prec_multi * recall_multi / (prec_multi + recall_multi)
    return [loss_bi, loss_multi, f1_bi, f1_multi]


map_relations = {}
# data_train = load_data('data/STAC/train.json', map_relations)
data_train = load_data('outputs/res.json', map_relations)
data_test = load_data('outputs/res.json', map_relations)
# data_test = load_data('data/STAC/test.json', map_relations)
vocab, embed = build_vocab(data_train)

print('Dataset sizes: %d/%d' % (len(data_train), len(data_test)))

model_dir, log_dir = FLAGS.prefix + '_model', FLAGS.prefix + '_log'

config = tf.compat.v1.ConfigProto()
# config.gpu_options.allow_growth = True
config.gpu_options.allow_growth = False
sess = tf.compat.v1.Session(config=config)

if __name__ == '__main__':
    with sess.as_default():
        model = Model(sess, FLAGS, embed, data_train)

        global_step = tf.Variable(0, name='global_step', trainable=False)
        global_step_inc_op = global_step.assign(global_step + 1)
        epoch = tf.Variable(0, name='epoch', trainable=False)
        epoch_inc_op = epoch.assign(epoch + 1)

        # saver = tf.compat.v1.train.Saver(max_to_keep=None, write_version=saver_pb2.SaverDef.V2, pad_step_number=True)
        checkpoint = tf.train.Checkpoint(model=model)
        manager = tf.train.CheckpointManager(checkpoint, directory="/tmp/model", max_to_keep=None)

        summary_list = ['loss_bi', 'loss_multi', 'f1_bi', 'f1_multi']
        summary_num = len(summary_list)
        len_output_feed = 6

        if FLAGS.train:
            if tf.train.get_checkpoint_state(model_dir):
                print('Reading model parameters from %s' % model_dir)
                # saver.restore(sess, tf.train.latest_checkpoint(model_dir))
                checkpoint.restore(sess, tf.train.latest_checkpoint(model_dir))
            else:
                print('Created model with fresh parameters')
                sess.run(tf.compat.v1.global_variables_initializer())
                model.initialize(vocab)

            print('Trainable variables:')
            for var in tf.compat.v1.trainable_variables():
                print(var)

            train_writer = tf.compat.v1.summary.FileWriter(os.path.join(log_dir, 'train'))
            test_writer = tf.compat.v1.summary.FileWriter(os.path.join(log_dir, 'test'))
            summary_placeholders = [tf.compat.v1.placeholder(tf.float32) for _ in range(summary_num)]
            summary_op = [tf.compat.v1.summary.scalar(summary_list[i], summary_placeholders[i]) for i in range(summary_num)]

            train_batches = get_batches(data_train, FLAGS.batch_size)
            test_batches = get_batches(data_test, FLAGS.batch_size)

            best_test_f1 = [0] * 2
            while epoch.eval() < FLAGS.num_epochs:
                epoch_inc_op.eval()
                summary_steps = 0

                random.shuffle(train_batches)
                start_time = time.time()
                s = np.zeros(len_output_feed)

                for batch in train_batches:
                    ops = model.step(batch, is_train=True)

                    for i in range(len_output_feed):
                        s[i] += ops[i]

                    summary_steps += 1
                    global_step_inc_op.eval()
                    global_step_val = global_step.eval()
                    if global_step_val % FLAGS.display_interval == 0:
                        print('epoch %d, global step %d (%.4fs/step):' % (
                            epoch.eval(), global_step_val,
                            (time.time() - start_time) * 1. / summary_steps
                        ))
                        summary_sum = get_summary_sum(s, summary_steps)
                        for k in range(summary_num):
                            print('  train %s: %.5lf' % (summary_list[k], summary_sum[k]))
                        print('  best test f1:', best_test_f1[0], best_test_f1[1])

                exit(20)
                summary_sum = get_summary_sum(s, len(train_batches))
                summaries = sess.run(summary_op, feed_dict=dict(zip(summary_placeholders, summary_sum)))
                for s in summaries:
                    train_writer.add_summary(summary=s, global_step=epoch.eval())
                print('epoch %d (learning rate %.5lf)' % \
                    (epoch.eval(), model.learning_rate.eval()))
                for k in range(summary_num):
                    print('  train %s: %.5lf' % (summary_list[k], summary_sum[k]))

                s = np.zeros(len_output_feed)
                random.seed(0)
                for batch in test_batches:
                    ops = model.step(batch)
                    for i in range(len_output_feed):
                        s[i] += ops[i]
                summary_sum = get_summary_sum(s, len(test_batches))
                summaries = sess.run(summary_op, feed_dict=dict(zip(summary_placeholders, summary_sum)))
                for s in summaries:
                    test_writer.add_summary(summary=s, global_step=epoch.eval())
                for k in range(summary_num):
                    print('  test %s: %.5lf' % (summary_list[k], summary_sum[k]))

                if summary_sum[-1] > best_test_f1[1]:
                    best_test_f1[0] = summary_sum[-2]
                    best_test_f1[1] = summary_sum[-1]

                print('  best test f1:', best_test_f1[0], best_test_f1[1])

                model.learning_rate_decay_op.eval()

                saver.save(sess, '%s/checkpoint' % model_dir, global_step=epoch.eval())
        else:
            print('Reading model parameters from %s' % model_dir)
            saver.restore(sess, tf.train.latest_checkpoint(model_dir))

            test_batches = get_batches(data_test, 1, sort=False)

            s = np.zeros(len_output_feed)
            random.seed(0)
            idx = 0
            for k, batch in enumerate(test_batches):
                if len(batch[0]['edus']) == 1:
                    continue
                ops = model.step(batch)
                for i in range(len_output_feed):
                    s[i] += ops[i]
                if compat.v1.flags.show_predictions:
                    idx = preview_data(batch, ops[-1], map_relations, vocab, idx)
            summary_sum = get_summary_sum(s, len(test_batches))

            print('Test:')
            for k in range(summary_num):
                print('  test %s: %.5lf' % (summary_list[k], summary_sum[k]))


