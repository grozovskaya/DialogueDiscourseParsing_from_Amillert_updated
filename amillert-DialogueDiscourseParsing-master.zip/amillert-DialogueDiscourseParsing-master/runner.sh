python ./data_pre.py ./data/s1-league3-game3/unannotated/ ./outputs/res.json
