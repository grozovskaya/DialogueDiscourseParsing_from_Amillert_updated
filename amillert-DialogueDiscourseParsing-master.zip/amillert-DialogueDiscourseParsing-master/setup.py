from distutils.core import setup

setup(
    name='DialogueDiscourseParsing',
    version='',
    packages=['libs'],
    url='',
    license='',
    author='amillert',
    author_email='',
    description=''
)
